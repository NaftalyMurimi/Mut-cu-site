import React from 'react'
import './calendar.css'
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
function Calendar() {
  return (
    <div className="full">
    <h2>Current and upcoming Events</h2>
        <FullCalendar className="fully"
      plugins={[ dayGridPlugin ]}
      initialView="dayGridMonth"

      events={[
          { title: 'Appreciating seasons and times', date: '2021-05-23' },
          { title: 'Appreciating seasons and times', date: '2021-05-30' },
          { title: 'In the closet', date: '2021-06-1' },
          { title: 'Baptism', date: '2021-06-13' },
          { title: 'Apologetics', date: '2021-06-01' },
          { title: 'Christian in the Market place', date: '2021-06-27' },
          { title: 'Gods world, word and work plan', date: '2021-07-04' },
          { title: 'Doing Love God’s way', date: '2021-07-11' },
          { title: 'Worship Sunday', date: '2021-07-18' },
          { title: 'Beyond Church Fellowship', date: '2021-07-25' },
          { title: 'The Christian Student', date: '2021-08-01' },
          { title: 'Slave to Righteousness', date: '2021-08-08' },

          { title: 'Bible Study Exposition', date: '2021-05-21' },
          { title: 'Worship Service', date: '2021-05-28' },
          { title: 'Giving', date: '2021-06-04' },
          { title: 'Prayer service', date: '2021-06-11' },
          { title: 'Worship Service', date: '2021-06-18' },
          { title: 'Elders’ Night', date: '2021-06-25' },
          { title: 'Prayer Service', date: '2021-07-02' },
          { title: 'Disciples are made', date: '2021-07-09' },
          { title: 'MULEWO', date: '2021-06-17' },
          { title: 'Prayer service', date: '2021-07-23' },
          { title: 'Holy Communion', date: '2021-07-30' },
          { title: 'Worship service', date: '2021-08-06' },
          { title: 'Guarding our heart', date: '2021-08-13'},
          { title: 'Bible Study Leaders’ Training', date: '2021-05-22' },
          { title: 'Leader’s Prayer center visit', date: '2021-05-29' },
          { title: 'CU Retreat', date: '2021-06-12' },
          { title: 'Prayer Walk', date: '2021-06-05' },
          { title: 'FOCUS Sunday', date: '2021-06-20' },
          { title: 'Baptism', date: '2021-06-20' },
          { title: 'Elders’ Night', date: '2021-06-25' },
          { title: 'Technical docket leaders’ training', date: '2021-06-26' },
          { title: 'Elders’ Sunday', date: '2021-06-27' },
          { title: 'Evangelism Week', date: '2021-07-04' },
          { title: 'Creative Day', date: '2021-07-10' },
          { title: 'Music/ Creative Fun Day', date: '2021-07-17' },
          { title: 'Bereans', date: '2021-07-25' }
        ]}
    />
  </div>
  )
}

export default Calendar

