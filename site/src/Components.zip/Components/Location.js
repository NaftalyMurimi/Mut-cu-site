import React from 'react'

import './Location.css';



function Location() {
    return (
        <div className="location">
            <div className="text">
                <h2><u>Location</u></h2>
                <h2><u>Our Office</u></h2>
                <p>Murang'a Christian Union Office is located at the university Assembly<br/>
                    hall Building. First Floor, Room No 2.
                </p>
                <p>Our services are held at the Ecop hall <span> Tuition Block </span>  
                or in the <span>Assembly hall</span></p>
                <button className="btn">Contact Us</button>

            </div>
            <div className="image">
                <img className="image" src="./images/see.PNG" alt="my location image"/>

            </div>
            
        </div>
    )
}

export default Location
