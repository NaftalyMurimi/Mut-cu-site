import React from 'react'
import './Events.css'
function Events() {
    //create an array of arrays called person
    const People = [
        {id: 1,  name: "Sub- committee members traing session"  ,image: "/images/SUBcom.JPG" },
        {id: 2, name: "2020 AGM held at the university Garden" ,image: "/images/AGM2021.JPG" },
        {id: 3, name:" The handing over on the 2020 AGM" ,image: "/images/ANDOVER.JPG" },
        {id: 4, name: "2020/2021 Exec members during the 2020 AGM together with 2021/2022 stem staff" ,image: "/images/ecol.JPG" },
        {id: 5, name: "Sunday service at the Ecop",image: "/images/sunday.JPG" },
        {id: 6, name: "MUTCU Associates present in the 2020 AGM (Associates Sunday)" , image: "/images/allumin.JPG" }
    ]
     /* using the mapping function display the above array
     const PeopleList = 
         map method accepts function as parameters*/
         
     
    return (
        <div className="people">
            <h1>My past and current events</h1>
       { People.map(People => 
        <div className="head">
            <img className="imgtag" src={People.image}/>
            <h3>  { People.name}  </h3>
            
        </div>
         )}
            
        </div>
    )
}

export default Events
